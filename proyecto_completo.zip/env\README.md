# Panel de Control para Compañía

Esta aplicación web proporciona un panel de control empresarial con las siguientes características:

- Sistema de inicio de sesión seguro
- Panel de control integrado con Power BI
- Visualizaciones en tiempo real, descriptivas, predictivas y de cuota de mercado
- Asistente virtual basado en LLM para consultas a la base de datos
- Gestión de equipo con capacidad para agregar y editar usuarios

## Requisitos

- Python 3.8+
- MySQL
- Credenciales de Power BI para acceder a los dashboards

## Instalación

1. Clonar este repositorio
2. Instalar las dependencias: `pip install -r requirements.txt`
3. Ejecutar la aplicación: `python app.py`
4. Acceder a la aplicación en `http://localhost:5000`

## Estructura del Proyecto

- `app.py`: Archivo principal de la aplicación
- `templates/`: Plantillas HTML
- `static/`: Archivos estáticos (CSS, JS, imágenes)
- `models/`: Modelos de base de datos
- `utils/`: Utilidades para la aplicación 